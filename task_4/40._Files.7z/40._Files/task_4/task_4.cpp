﻿/*
	4. Написать программу, которая разбивает файл на кусочки
указанного размера, а затем создает копию исходного файла
из этих кусков.

Путь к входному/выходному файлу задает пользователь !

НЕ РАБОТАЕТ !!!

2.57.15
*/

#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <io.h>
using namespace std;

// Делит, в бинарном режиме, любой файл на кусочки (размер, куска в байтах задает пользователь) 
// и возвращает размер файла в байтах
unsigned long int CutFileIntoPieces(const char* filename, int onePieceSizeInBytes)
{
	FILE* f1 = nullptr;
	fopen_s(&f1, filename, "rb");
	if (f1 == nullptr)
	{
		perror("Error opening");
		return 0;
	}
	int lenght = _filelength(_fileno(f1)); // _fileno (получает дескриптор), _filelength (дает размер файла в байтах)
	char* bufForDataPiece = new char[onePieceSizeInBytes]; // буфер на 1 кусочек
	memset(bufForDataPiece, 0, onePieceSizeInBytes);
	char bufferFileName[20];
	FILE* f2 = nullptr;
	for (int i = 0; i < lenght / onePieceSizeInBytes + 1; i++)
	{
		snprintf(bufferFileName, sizeof(bufferFileName), "file_%d.bin", i);
		fopen_s(&f2, bufferFileName, "wb");
		int read = fread(bufForDataPiece, sizeof(char), onePieceSizeInBytes, f1);
		fwrite(bufForDataPiece, sizeof(char), read, f2);
	}
	delete[]bufForDataPiece;
	fclose(f1);
	fclose(f2);

	return lenght;
}

// Собирает, в бинарном режиме, файл из кусочков
void CollectFileFromPieces(const char* fileNameResult, int fileSize, int onePieceSizeInBytes)
{
	FILE* f1 = nullptr;
	char bufferFileName[20]; // имя кусочка
	char* buf = new char[fileSize]; // память под результирующий файл
	memset(buf, 0, fileSize);
	for (int i = 0; i < fileSize / onePieceSizeInBytes + 1; i++)
	{
		snprintf(bufferFileName, sizeof(bufferFileName), "file_%d.bin", i); // формируем имя по шаблону
		fopen_s(&f1, bufferFileName, "rb");
		fread(buf, sizeof(char), onePieceSizeInBytes, f1);
	} // ОШИБКА <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	FILE* f2 = nullptr;
	fopen_s(&f2, fileNameResult, "wb");
	fwrite(buf, sizeof(char), fileSize, f2);
	delete[]buf;
	fclose(f1);
	fclose(f2);
}

int main()
{
	SetConsoleCP(1251);
	/*
	Задает кодовую страницу ввода, используемую консолью, связанной с вызывающим процессом.
	Консоль использует страницу входного кода для преобразования ввода с клавиатуры
	в соответствующее символьное значение.
	*/
	SetConsoleOutputCP(1251);
	/*
	Задает выходную кодовую страницу, используемую консолью, связанной с вызывающим процессом.
	Консоль использует свою кодовую страницу вывода для преобразования символьных значений,
	записанных различными функциями вывода, в изображения, отображаемые в окне консоли.
	*/

	char filename[MAX_PATH];
	cout << "Введите путь к исходному файлу: ";
	cin.getline(filename, MAX_PATH);
	cout << "Введите размер 1 кусочка в байтах: ";
	int  onePieceSizeInBytes{ 0 };
	cin >> onePieceSizeInBytes;
	int fileSize = CutFileIntoPieces(filename, onePieceSizeInBytes);
	cout << "Введите путь к результирующему файлу : ";
	char fileNameResult[MAX_PATH];
	CollectFileFromPieces(fileNameResult, fileSize, onePieceSizeInBytes);
}